"""Pydantic スキーマ定義。"""

